## CLI-tool to initiate game checkers

<pre>
NAME:
   game - initiate checkers run

USAGE:
   game [global options] command [command options] [arguments...]

VERSION:
   0.0.0

COMMANDS:
   help, h	Shows a list of commands or help for one command

GLOBAL OPTIONS:
   --list, -l		get available tasks
   --help, -h		show help
   --version, -v	print the version
</pre>